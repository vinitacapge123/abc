package recharge.userinterface;
import java.sql.*;
import java.util.*;

import org.omg.CORBA.portable.Delegate;

import recharge.bean.Recharge;
import recharge.dbutil.IQueryMapper;
import recharge.service.IRechargeService;
import recharge.service.RechargeService;

public class RechargeUI {

	static Scanner sc=new Scanner(System.in);
	static Recharge rc = null;
	static IRechargeService rcser = null;
	public static void main(String args[]) throws SQLException
	{

		System.out.println("***********WELCOME TO RECHARGE PORTAL***********");
		System.out.println("1.RECHARGE");
		System.out.println("2.KNOW RECHARGE DETAILS USING YOUR RECHARGE_ID ");
		System.out.println("3.KNOW ALL THE RECHARGE DEATAILS  ");
		System.out.println("4.DELETE DETAILS BY RECHARGE ID  ");
		System.out.println("5.UPDATE RECHARGE DEATAILS  ");
		System.out.println("6. exit");
		System.out.println();
		System.out.println(IQueryMapper.MSG_FOR_USER);
		System.out.println();
		int option=sc.nextInt();
		switch(option){
		case 1:
			rc = new Recharge();
			System.out.println("Enter name");
			rc.setUsername(sc.next());
			System.out.println("Enter Mobile no");
			rc.setMobileno(sc.next());
			System.out.println("Enter mailid");
			rc.setMailID(sc.next());
			System.out.println("Enter Plan name");
			rc.setPlanName(sc.next());
			int rs = rechargeplan(rc);
			System.out.println(rs + " row created");
			break;

		case 2:
            System.out.println("Enter Recharge ID to be searched");
			int rid1=sc.nextInt();
			
			Recharge r = retrieveById(rid1);
			System.out.println(r);
			break;

		case 3:
			retrieveAll();
			ArrayList<Recharge> r3=retrieveAll();
			System.out.println(r3);
			break;

		case 4:
			System.out.println("Enter the Recharge ID to be deleted");
			int rid2=sc.nextInt();
			
			int status=0;
			if(status>0)
			{
				System.out.println(status+" row deleted");
			}
			else
			{
				System.out.println("Invalid Recharge ID");
			}
		case 5:
			
			
		case 6:
			System.exit(0);
		default:
              System.out.println("please enter a valid option between 1-4");
		}
	}
	private static int delete(int rid2) throws SQLException {
		rcser=new RechargeService();
        return rcser.delete(rid2);
	
	}
	private static ArrayList<Recharge> retrieveAll() throws SQLException {
		rcser=new RechargeService();
        return rcser.retreieveAll();
	}
	private static Recharge retrieveById(int rid) throws SQLException {
		rcser=new RechargeService();
		return rcser.retrieveById(rid);
	}
	public static int rechargeplan(Recharge rc) throws SQLException {
		
		rcser = new RechargeService();
	
		return rcser.recharge(rc);
	}

	
}


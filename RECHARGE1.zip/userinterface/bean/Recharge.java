package recharge.bean;

public class Recharge {
public Recharge() {
	
}
private String username;
private String mailID;
private String mobileno;
private float amount;
private String PlanName;
private int rechargeId;
private String rechargeDate;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getMailID() {
	return mailID;
}
public void setMailID(String mailID) {
	this.mailID = mailID;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}
public String getPlanName() {
	return PlanName;
}
public void setPlanName(String planName) {
	PlanName = planName;
}
public int getRechargeId() {
	return rechargeId;
}
public void setRechargeId(int rechargeId) {
	this.rechargeId = rechargeId;
}
public String getRechargeDate() {
	return rechargeDate;
}
public void setRechargeDate(String rechargeDate) {
	this.rechargeDate = rechargeDate;
}
public Recharge(String username, String mailID, String mobileno, float amount, String planName, int rechargeId,
		String rechargeDate) {
	super();
	this.username = username;
	this.mailID = mailID;
	this.mobileno = mobileno;
	this.amount = amount;
	PlanName = planName;
	this.rechargeId = rechargeId;
	this.rechargeDate = rechargeDate;
}
@Override
public String toString() {
	return "\nrecharge [username=" + username + ", mailID=" + mailID + ", mobileno=" + mobileno + ", amount=" + amount
			+ ", PlanName=" + PlanName + ", rechargeId=" + rechargeId + ", rechargeDate=" + rechargeDate + "]";
}

}

package recharge.dbutil;

public interface IQueryMapper {
    public static final	String MSG_FOR_USER="Choose your option";
	public static final String MSG_SELECT_YOUR_PLAN="Select your Plan";
	public static final String MSG_SELECT_YOUR_PLAN1="RC 99";
	public static final String MSG_SELECT_YOUR_PLAN2="RC 200";
	public static final String MSG_SELECT_YOUR_PLAN3="RC 300";
	public static final	String MSG_RECHARGE_USER_NAME="Enter Your Name";
	public static final String MSG_MOBILE_NO="Enter Your Mobile Number";
	public static final	String MSG_MAIL_ID="Enter Your Mail ID";
	public static final String RETRIEVE_RECHARGE_DEATAILS_BY_ID="Veiw Recharge Details by Recharge ID";
	public static final String RETRIEVE_RECHARGES="Veiw All Recharge Details";
	}


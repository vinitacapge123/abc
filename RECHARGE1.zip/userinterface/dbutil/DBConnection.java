package recharge.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	static Connection conn=null;
	public static Connection getConnected() throws SQLException{
		conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg1115","training1115");
		return  conn;
	}
}

package recharge.service;

import java.sql.SQLException;
import java.util.ArrayList;

import recharge.bean.Recharge;

public interface IRechargeService {
	
	public boolean validDetails(Recharge r);
	public int recharge(Recharge r)throws SQLException ;
	public Recharge retrieveById(int rid) throws SQLException;
	public ArrayList<Recharge> retreieveAll()throws SQLException;
	public  int delete(int id) throws SQLException;

	
}

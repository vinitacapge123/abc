package recharge.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import recharge.bean.Recharge;
import recharge.dao.IRechargeDAO;
import recharge.dao.RechargeDAO;

public class RechargeService implements IRechargeService {
	static Scanner sc=new Scanner(System.in);
	IRechargeDAO rech=null;
	RechargeService rech1=null;

	@Override
	public boolean validDetails(Recharge r) {
		String username = r.getUsername();
		String namePattern="^[A-Z]{1}[a-z]{4,15}";//Monugaud
		Pattern p2 = Pattern.compile(namePattern);
		Matcher m2=p2.matcher(username);
		if(m2.find())
		{
			boolean flag = true;
		}
		else
		{
			System.out.println("Invalid Name Pattern");
			return false;
		}
		
		
		String mailId = r.getMailID();
		String emailpattern = "^[A-Za-z0-9._-]{1,15}[@][a-zA-Z]{1,10}[.][a-zA-Z]{2,4}$";
		Pattern p = Pattern.compile(emailpattern);
		Matcher m=p.matcher(mailId);
		if(m.find())
		{
			boolean flag = true;
		}
		else
		{
			System.out.println("Invalid mail Pattern");
		}
		
		String mob = r.getMobileno();
		
		String mobilePattern="^[6789]{1}[0-9]{9}";
		Pattern p1 = Pattern.compile(mobilePattern);
		Matcher m1=p1.matcher(mob);
		if(m1.find())
		{
			boolean flag = true;
		}
		else
		{
			System.out.println("Invalid Mobie Pattern");
		}
		return false;
		
		/*if(i>0 && j>0 && k>0)
		{
			return true;
		}
		else{
			return false;
		}*/
	}
	@Override
	public int recharge(Recharge r) throws SQLException 
	{
		rech1 = new RechargeService();
		rech = new RechargeDAO();

		if(rech1.validDetails(r))
		{
			return rech.recharge(r);
		}
		else
		{
			System.out.println("Inavlid input");
			return 0;
		}
	}
	@Override
	public Recharge retrieveById(int rid1) throws SQLException {

		rech = new RechargeDAO();
		return rech.retrieveById(rid1);
	}
	@Override
	public ArrayList<Recharge> retreieveAll() throws SQLException {

		rech = new RechargeDAO();
		return rech.retreieveAll();
	}
	@Override
	public int delete(int id) throws SQLException {
		rech = new RechargeDAO();
		return rech.delete(id);
	}


}

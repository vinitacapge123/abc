package recharge.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.util.ArrayList;
import java.util.Scanner;

import recharge.bean.Recharge;
import recharge.dbutil.DBConnection;
import recharge.dbutil.IQueryMapper;

public class RechargeDAO implements IRechargeDAO {
	static Scanner s=new Scanner(System.in);
	static Connection con=null;
	static Recharge r=null;
	static RechargeDAO d = null;
	public static int rechargeplan() throws SQLException {
		r = new Recharge();
		d = new RechargeDAO();
		con=DBConnection.getConnected();
		System.out.println(IQueryMapper.MSG_SELECT_YOUR_PLAN);
		System.out.println(IQueryMapper.MSG_SELECT_YOUR_PLAN1);
		System.out.println(IQueryMapper.MSG_SELECT_YOUR_PLAN2);
		System.out.println(IQueryMapper.MSG_SELECT_YOUR_PLAN3);
		int i = s.nextInt();
		int amt=0;
		switch(i)
		{
		case 1:
			amt=99;
			break;
		case 2:
			amt=200;
			break;
		case 3:
			amt=300;
			break;
		default :
			System.out.println("Choose From above Plan");
		}
		return amt;
	}


	
	@Override
	public  int recharge(Recharge r) throws SQLException
	{
		con = DBConnection.getConnected();
		int amt = rechargeplan();
		String qry="insert into recharge values(seq_reg2.NEXTVAL,?,SYSDATE,?,?,?,?)";
		PreparedStatement st=con.prepareStatement(qry);
		st.setInt(1,amt);
		st.setString(2,r.getPlanName());
		st.setString(3,r.getUsername());
		st.setString(4,r.getMobileno());
		st.setString(5,r.getMailID());
		int status = st.executeUpdate();
		st=con.prepareStatement("SELECT seq_reg2.CURRVAL FROM DUAL");
		ResultSet rs=st.executeQuery();

		if(rs.next()){
			System.out.println("Recharge Id="+rs.getInt(1));
		}
		return status ;
	}

	@Override
	public Recharge retrieveById(int rid) throws SQLException {
		con = DBConnection.getConnected();
		String str="select * from recharge where rid=?";
		PreparedStatement st=con.prepareStatement(str);
		st.setInt(1,rid);
		ResultSet rs=st.executeQuery();
		Recharge r=null;
		if(rs.next()){
			r= new Recharge();
			r.setRechargeId(rs.getInt(1));
			r.setAmount(rs.getInt(2));
			r.setRechargeDate(rs.getString(3));
			r.setPlanName(rs.getString(4));
			r.setUsername(rs.getString(5));
			r.setMobileno(rs.getString(6));
			r.setMailID(rs.getString(7));
		}
		return r;
	}

	@Override
	public ArrayList<Recharge> retreieveAll() throws SQLException {
		
		con = DBConnection.getConnected();
		ArrayList<Recharge> r2=new ArrayList<Recharge>();
		String str="select * from recharge";
		PreparedStatement st=con.prepareStatement(str);
		ResultSet rs=st.executeQuery();
		Recharge r=null;
		while(rs.next()){
			r=new Recharge();
			r.setRechargeId(rs.getInt(1));
			r.setAmount(rs.getInt(2));
			r.setRechargeDate(rs.getString(3));
			r.setPlanName(rs.getString(4));
			r.setUsername(rs.getString(5));
			r.setMobileno(rs.getString(6));
			r.setMailID(rs.getString(7));
			r2.add(r);//add records(objects) to array list
		}
		return r2;
	}



	@Override
	public int delete(int id) throws SQLException {
		con = DBConnection.getConnected();
		String str="delete from recharge where rid=?";
		PreparedStatement st=con.prepareStatement(str);
		st.setInt(1,id);
		int status = st.executeUpdate();
		ResultSet rs=st.executeQuery();
		System.out.println(status+" row deleted");
		return status;
	}



	@Override
	public boolean validDetails(Recharge r) {
		
		return false;
	}

}

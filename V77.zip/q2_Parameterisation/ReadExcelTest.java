package com.cg.testng;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.cg.parameterisation.ReadExcel;


public class ReadExcelTest {
	static WebDriver driver;
	static XSSFSheet sheet1;
	static XSSFWorkbook wb1;
	 static int rowTotal;
	@BeforeClass
	public void beforeClass() throws IOException
	{
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		  driver = new ChromeDriver();
		  System.out.println("before class");
		  File src= new File("D:\\Data2.xlsx");
			//using Java API specify workbook path
			FileInputStream fis = new FileInputStream(src);
			//to load entire workbook use XSSFWorkbook class
			 wb1 = new XSSFWorkbook(fis);  //XSS used for .xlsx file
			//to get the access of sheet 1 use XSSFSheet class
			 sheet1 = wb1.getSheetAt(0);
			
		 rowTotal = sheet1.getLastRowNum();

			if ((rowTotal > 0) || (sheet1.getPhysicalNumberOfRows() > 0)) {
			    rowTotal++;
			}
		  
	}
	@BeforeTest
	public void beforeTest()
	{
		 System.out.println("before test");
	}
  @Test
  public void readAllDataTest() throws IOException, InterruptedException {
	
	  ReadExcel excel=new ReadExcel();
	  excel.readAllData(driver,rowTotal,sheet1,wb1);
  }
}

/**
 * 
 */
package com.cg.parameterisation;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * @author skuma545
 *
 */
public class ReadExcel {
	
	static XSSFSheet sheet1;
	static XSSFWorkbook wb1;
	static WebDriver driver;
	static int rowTotal;
	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
		driver = new ChromeDriver();
		File src= new File("D:\\Data2.xlsx");
		//using Java API specify workbook path
		FileInputStream fis = new FileInputStream(src);
		//to load entire workbook use XSSFWorkbook class
		wb1 = new XSSFWorkbook(fis);  //XSS used for .xlsx file
		//HSSFWorkbook wb1 = new HSSFWorkbook(fis); //HSS used for .xls file
		//to get the access of sheet 1 use XSSFSheet class
		sheet1 = wb1.getSheetAt(0);

		rowTotal = sheet1.getLastRowNum();

		if ((rowTotal > 0) || (sheet1.getPhysicalNumberOfRows() > 0)) {
			rowTotal++;
		}

		//using loop to retrieve all data from excel sheet
		//readAllData(rowTotal);

	}

	public void readAllData(WebDriver driver,int rowTotal,XSSFSheet sheet1, XSSFWorkbook wb1) throws IOException, InterruptedException {
		// TODO Auto-generated method stub

		for(int i=1;i<rowTotal;i++)
		{

			driver.get("file:///D:/example-javascript-form-validation.html");
			String userid=sheet1.getRow(i).getCell(0).getStringCellValue();
			String password=sheet1.getRow(i).getCell(1).getStringCellValue();
			String name=sheet1.getRow(i).getCell(2).getStringCellValue();
			String address=sheet1.getRow(i).getCell(3).getStringCellValue();
			
			System.out.println("userid:"+userid);
			System.out.println("password:"+password);
			
			driver.findElement(By.id("usrID")).sendKeys(userid);
			driver.findElement(By.id("pwd")).sendKeys(password);
			driver.findElement(By.id("usrname")).sendKeys(name);
			driver.findElement(By.id("addr")).sendKeys(address);
			
				Select sel=new Select(driver.findElement(By.xpath("html/body/form/ul/li[10]/select")));
				sel.selectByIndex(2);
			
			
			driver.findElement(By.name("zip")).sendKeys("121212");
			driver.findElement(By.name("email")).sendKeys("a@b.com");
			driver.findElement(By.xpath("html/body/form/ul/li[16]/input")).click();
			driver.findElement(By.name("desc")).sendKeys("about");
			
			Thread.sleep(1000);
			driver.findElement(By.name("submit")).click();
			//driver.close();	
		}
		driver.close();
		wb1.close();  
	}

}

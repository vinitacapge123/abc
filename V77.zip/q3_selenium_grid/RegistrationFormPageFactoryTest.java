package com.cg.testng;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.cg.registration.RegistrationFormPageFactory;

/*
 *  author:Shashi kumar 158220
 *  using selenium-server-standalone-2.47.1.jar
 * 
 * 
 */

public class RegistrationFormPageFactoryTest {
	static WebDriver driver;
	RegistrationFormPageFactory registrationFormPageFactory;
	@BeforeClass
	public void beforeClass() throws MalformedURLException
	{
		
		System.setProperty("webdriver.chromedriver.driver", "D:/chromedriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setBrowserName("chrome");
		capabilities.setCapability("webdriver.chromedriver.driver", "D:/chromedriver.exe");		
		capabilities.setPlatform(Platform.WINDOWS);
		//capabilities.setVersion(version);
		WebDriver driver = new RemoteWebDriver(new URL("http://localhost:6666/wd/hub"), capabilities);
		registrationFormPageFactory = PageFactory.initElements(driver, RegistrationFormPageFactory.class);
		
		driver.get("file:///D:/example-javascript-form-validation.html");
	}
	
	@Test(priority=14)
	  public void verifyTitleTest() {
		
		String expectedTitle="JavaScript Form Validation using a sample registration form";
		  registrationFormPageFactory.verifyTitle(expectedTitle);
	  }
	
	@Test(priority=15)
	  public void verifyHeadingTest() {
		String expectedHeading="Registration Form";
		  registrationFormPageFactory.verifyHeading(expectedHeading);
	  }
	
	@Test(priority=1)
	  public void enterUserIdTest() {
		if(registrationFormPageFactory.isUserIdFieldDisplayed())
		  registrationFormPageFactory.enterUserId("skuma");
	  }
	
	@Test(priority=2)
	  public void enterPasswordTest() {
		
		if(registrationFormPageFactory.isPasswordFieldDisplayed())
			
		  registrationFormPageFactory.enterPassword("pwadsfafs");
	  }
	
  @Test(priority=3)
  public void enterNameTest() {
	  if(registrationFormPageFactory.isNameFieldDisplayed())
	  registrationFormPageFactory.enterName("Hello");
	  
  }
  
  @Test(priority=4)
  public void enterAddressTest() {
	  if(registrationFormPageFactory.isAddressFieldDisplayed())
	  registrationFormPageFactory.enterAddress("ok");
  }
  
  @Test(priority=5)
  public void selectCountryTest() {
	  if(registrationFormPageFactory.isSelectCountryDropDownDisplayed())
	  registrationFormPageFactory.selectCountry(2);
  }
  
  @Test(priority=6)
  public void enterZipCodeTest() {
	  if(registrationFormPageFactory.isZipCodeFieldDisplayed())
	  registrationFormPageFactory.enterZipCode("801111");
  }
  
  @Test(priority=7)
  public void enterEmailTest() {
	  if(registrationFormPageFactory.isEmailFieldDisplayed())
	  registrationFormPageFactory.enterEmail("abc@gog.com");
  }
 
  @Test(priority=8)
  public void selectSexMaleTest() {
	  if(registrationFormPageFactory.isMaleRadioFieldDisplayed())
	  registrationFormPageFactory.selectRadioMale(true);
  }
  
  @Test(priority=9)
  public void selectSexFemaleTest() {
	  if(registrationFormPageFactory.isFemaleRadioFieldDisplayed())
	  registrationFormPageFactory.selectRadioFemale(true);
  }
  
  @Test(priority=10)
  public void selectLangEngTest() {
	  if(registrationFormPageFactory.isEnglishChbxFieldDisplayed())
	  registrationFormPageFactory.selectChbxEng(true);
	  
  }
  
  @Test(priority=11)
  public void selectNonLangEngTest() {
	  if(registrationFormPageFactory.isNonEnglishChbxFieldDisplayed())
	  registrationFormPageFactory.selectChbNonEng(false);
  }
  
  @Test(priority=12)
  public void enterAboutTest() {
	  if(registrationFormPageFactory.isAboutFieldDisplayed())
	  registrationFormPageFactory.enterAbout("hello i am");
  }
  
  @Test(priority=13)
  public void click_submit() {
	  if(registrationFormPageFactory.isSubmitBtnDisplayed())
	  registrationFormPageFactory.click_submit();
  }
}

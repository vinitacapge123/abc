/**
 * 
 */
package com.cg.registration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

/*
 *  author:Shashi kumar 158220
 *  using selenium-server-standalone-2.47.1.jar
 * 
 * 
 */
public class RegistrationFormPageFactory {
	WebDriver driver;
	//creating parameterized constructor to initialize WebDriver reference
	public RegistrationFormPageFactory(WebDriver driver)
	{
		this.driver =driver;
	}
	
	@FindBy(xpath="/html/body/h1")
	@CacheLookup // to store the element in cache memory
	public WebElement heading;
	
	@FindBy(xpath=".//*[@id='usrID']")
	@CacheLookup // to store the element in cache memory
	public WebElement usrID;
	
	@FindBy(id="pwd")
	@CacheLookup // to store the element in cache memory
	public WebElement pwd;
	
	//using How class	
	@FindBy(how=How.ID, using="usrname")
	@CacheLookup
	public WebElement username;
	
	//using Xpath
	@FindBy(how=How.XPATH, using=".//*[@id='addr']")
	@CacheLookup
	public WebElement address;
	
	@FindBy(name="country")
	@CacheLookup
	public WebElement selectCoutry;
	
	@FindBy(name="zip")
	@CacheLookup
	public WebElement zipcode;
	
	@FindBy(name="email")
	@CacheLookup
	public WebElement email;
	
	@FindBy(xpath="/html/body/form/ul/li[16]/input")
	@CacheLookup
	public WebElement radioMale;
	
	@FindBy(xpath="/html/body/form/ul/li[17]/input")
	@CacheLookup
	public WebElement radioFemale;
	
	@FindBy(xpath="html/body/form/ul/li[19]/input")
	@CacheLookup
	public WebElement langEngChbx;
	
	@FindBy(xpath="html/body/form/ul/li[20]/input")
	@CacheLookup
	public WebElement langNonEngChbx;
	
	@FindBy(xpath=".//*[@id='desc']")
	@CacheLookup
	public WebElement about;
	
	@FindBy(xpath="html/body/form/ul/li[23]/input")
	@CacheLookup
	public WebElement submit;
			

	public void enterUserId(String uid)
	{
		usrID.sendKeys(uid);	
	}
	
	public void enterPassword(String pw)
	{
		pwd.sendKeys(pw);
	}
	
	public void enterName(String uName)
	{
		username.sendKeys(uName);
	}
	
	public void enterAddress(String ad)
	{
		address.sendKeys(ad);
	}
	public void selectCountry(int countryIndex)
	{
		Select sel=new Select(selectCoutry);
		sel.selectByIndex(countryIndex);
	}
	
	public void enterZipCode(String  zip)
	{
		zipcode.sendKeys(zip);
	}
	
	public void enterEmail(String e)
	{
		email.sendKeys(e);
	}
	
	public void selectRadioMale(boolean isClicked)
	{
		if(isClicked)
			radioMale.click();
	}
	public void selectRadioFemale(boolean isClicked)
	{
		if(isClicked)
			radioFemale.click();
	}
	
	public void selectChbxEng(boolean isClicked)
	{
		if(isClicked)
			langEngChbx.click();
	}
	public void selectChbNonEng(boolean isClicked)
	{
		if(isClicked)
			langNonEngChbx.click();
	}
	
	public void enterAbout(String e)
	{
		about.sendKeys(e);
	}
	
	public void click_submit(){
		submit.click();
	}
	
	//Methhods to check whether the fields are displayed and enabled
	public boolean isUserIdFieldDisplayed()
	{
		if(usrID.isDisplayed()&&usrID.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isPasswordFieldDisplayed()
	{
		if(pwd.isDisplayed()&&pwd.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isNameFieldDisplayed()
	{
		if(username.isDisplayed()&&username.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isAddressFieldDisplayed()
	{
		if(address.isDisplayed()&&address.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isSelectCountryDropDownDisplayed()
	{
		if(selectCoutry.isDisplayed()&&selectCoutry.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isZipCodeFieldDisplayed()
	{
		if(zipcode.isDisplayed()&&zipcode.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isEmailFieldDisplayed()
	{
		if(email.isDisplayed()&&email.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isMaleRadioFieldDisplayed()
	{
		if(radioMale.isDisplayed()&&radioMale.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isFemaleRadioFieldDisplayed()
	{
		if(radioFemale.isDisplayed()&&radioFemale.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isEnglishChbxFieldDisplayed()
	{
		if(langEngChbx.isDisplayed()&&langEngChbx.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isNonEnglishChbxFieldDisplayed()
	{
		if(langNonEngChbx.isDisplayed()&&langNonEngChbx.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isAboutFieldDisplayed()
	{
		if(about.isDisplayed()&&about.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isSubmitBtnDisplayed()
	{
		if(submit.isDisplayed()&&submit.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
			
	public void verifyTitle(String expected)
	{
		String actual = driver.getTitle();
		if(actual.contentEquals(expected))
		{
			//System.out.println("Title Verification - Passed");
		}
		else
		{
			//System.out.println("Title Verification - Failed");
			driver.quit();
		}
			
	}
	public void verifyHeading(String expected)
	{
		String actual = heading.getText();
		if(actual.contentEquals(expected))
		{
			//System.out.println("Heading Verification - Passed");
			 
		}
		else
		{
			//System.out.println("Heading Verification - Failed");
			driver.quit();
		}
			
	}
	
	public void verifyuserId() throws InterruptedException  
	{
		Boolean fn=usrID.isDisplayed();
		if(fn) 
		{
			System.out.println("First Name textbox present");
			enterUserId("");
			submit.click();
			Thread.sleep(3000);;
			Alert alert = driver.switchTo().alert();
			String expectedAlertMessage="User Id should not be empty / length be between 5 to 12";
		    String actualAlertMessage= driver.switchTo().alert().getText();
		    if(expectedAlertMessage.contentEquals(actualAlertMessage))
		    {
		    	System.out.println("Alert message verification for first name - Passed");
		    	alert.accept();
		    	enterName("shashi");
		    }
		    else
		    {
		    	System.out.println("Alert message verification for first name - Failed");
			}
		    
		}
		else
		{
			System.out.println("First Name textbox not present");
		}
		
	}
}


//import { Component } from '@angular/core';


export class EmployeeList
{
	empId:number;
	empName:string;
	empSalary:number;
	empDepartment:string;
}
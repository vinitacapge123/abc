"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var AppEmployeeComponent = (function () {
    function AppEmployeeComponent() {
        this.employees = [];
    }
    AppEmployeeComponent.prototype.addDetails = function () {
        if (this.empId != null && this.empName != null && this.empSalary != null && this.empDepartment != null) {
            var emp = { empId: this.empId, empName: this.empName, empSalary: this.empSalary, empDepartment: this.empDepartment };
            this.employees.push(emp);
            this.clearAll();
        }
        else {
            alert("Insert all fields");
        }
    };
    AppEmployeeComponent.prototype.putData = function (empId, empName, empSalary, empDepartment) {
        this.empId2 = empId;
        this.empName2 = empName;
        this.empSalary2 = empSalary;
        this.empDepartment2 = empDepartment;
    };
    //Update Record
    AppEmployeeComponent.prototype.updateData = function () {
        if (this.empId2 != 0) {
            var obj = null;
            for (var _i = 0, _a = this.employees; _i < _a.length; _i++) {
                obj = _a[_i];
                if (obj.empId == this.empId2) {
                    break;
                }
            }
            obj.empName = this.empName2;
            obj.empSalary = this.empSalary2;
            obj.empDepartment = this.empDepartment2;
            this.clearAll();
        }
        else {
            console.log("error");
        }
    };
    AppEmployeeComponent.prototype.delete = function (emp) {
        console.log("Shilpa");
        console.log(emp);
        var index = this.employees.indexOf(emp);
        console.log(index);
        this.employees.splice(index);
        this.clearAll();
    };
    AppEmployeeComponent.prototype.myFunc1 = function () {
        this.employees.sort(function (name1, name2) {
            if (parseInt(name1.empId) < parseInt(name2.empId)) {
                return -1;
            }
            else if (parseInt(name1.empId) > parseInt(name2.empId)) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    AppEmployeeComponent.prototype.myFunc2 = function () {
        this.employees.sort(function (name1, name2) {
            if (name1.empName.toLowerCase() < name2.empName.toLowerCase()) {
                return -1;
            }
            else if (name1.empName.toLowerCase() > name2.empName.toLowerCase()) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    AppEmployeeComponent.prototype.myFunc3 = function () {
        this.employees.sort(function (name1, name2) {
            if (parseInt(name1.empSalary) < parseInt(name2.empSalary)) {
                console.log(name1.empSalary);
                return -1;
            }
            else if (parseInt(name1.empSalary) > parseInt(name2.empSalary)) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    AppEmployeeComponent.prototype.myFunc4 = function () {
        this.employees.sort(function (name1, name2) {
            if (name1.empDepartment.toLowerCase() < name2.empDepartment.toLowerCase()) {
                return -1;
            }
            else if (name1.empDepartment.toLowerCase() > name2.empDepartment.toLowerCase()) {
                return 1;
            }
            else {
                return 0;
            }
        });
    };
    AppEmployeeComponent.prototype.clearAll = function () {
        this.empId = null;
        this.empName = null;
        this.empSalary = null;
        this.empDepartment = null;
        this.empId2 = null;
        this.empName2 = null;
        this.empSalary2 = null;
        this.empDepartment2 = null;
    };
    return AppEmployeeComponent;
}());
AppEmployeeComponent = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.employeecomponent.html'
    })
], AppEmployeeComponent);
exports.AppEmployeeComponent = AppEmployeeComponent;
//# sourceMappingURL=app.employeecomponent.js.map
package com.cg.ems.test;

import org.junit.*;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeIssueException;

public class TestCase {
	static IEmployeeDAO edo=null;
	@BeforeClass
	public static void initialize(){
		edo= new EmployeeDAOImpl();
	}
	@Test
public void addEmployeeTest()
{
		Employee e=new Employee();
		e.setName("Simran");
		e.setMobile("844785459");
		e.setMail("surbhii@gmail.com");
		e.setSal(225);
		try{
			Assert.assertEquals("Failure",119,edo.addEmployee(e));
		}
		catch(EmployeeIssueException e1)
		{
			System.out.println("Error "+e1.getMessage());
		}
}
	@Test
		public void addEmployeeTest1()
		{
				Employee e=new Employee();
				e.setName("Sagar");
				e.setMobile("8447845219");
				e.setMail("sagari@gmail.com");
				e.setSal(285);
				try{
					Assert.assertEquals("Failure",120,edo.addEmployee(e));
				}
				catch(EmployeeIssueException e1)
				{
					System.out.println("Error "+e1.getMessage());
				}
	
}
}

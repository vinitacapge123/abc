package com.cg.ems.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeIssueException;

public interface IEmployeeService {

	//validation
	public boolean validateEmail(String email);
	public boolean validateName(String name);
	public boolean validateNumber(String mob);
	public int addEmployee(Employee emp) throws EmployeeIssueException;
	public int deleteByEmployeeId(int eid) throws EmployeeIssueException;
	public Employee retrieveByEmployeeId(int searchId) throws EmployeeIssueException, SQLException;
	public ArrayList<Employee> retrieveAllEmployeeinfo() throws EmployeeIssueException;
	public String updateEmployeeId(int id, String name)throws EmployeeIssueException, SQLException;
}

package com.cg.ems.service;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ems.bean.Employee;
import com.cg.ems.dao.EmployeeDAOImpl;
import com.cg.ems.dao.IEmployeeDAO;
import com.cg.ems.exception.EmployeeIssueException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDAO  edao=null;
	Employee emp5=new Employee();
	@Override
	public boolean validateName(String name) {
		String pattern="[A-Z]{1}[a-zA-Z0-0]{4,9}$";
		Pattern p1=Pattern.compile(pattern);
		Matcher m=p1.matcher(name);
		if(m.find()){
				return true;
		}
		
	return false;
	}
	@Override
	public boolean validateEmail(String email) {
		String	a = "^[a-zA-Z\\._0-9]{4,10}[@][a-z]{3,9}[\\.][a-z]{2,3}$"; //email validation								
		Pattern pa = Pattern.compile(a);    
		Matcher matc = pa.matcher(email);    
		   if(matc.find())   
		   {
			 return true;
		   }
		   return false;
	}
	public boolean validateNumber(String mob) {
		String a1="^[6789]{1}[0-9]{9}$";							
		Pattern pa = Pattern.compile(a1);    
		Matcher matc = pa.matcher(mob);    
		   if(matc.find())   
		   {
			 return true;
		   }
		   return false;
	}
	

	@Override
	public int addEmployee(Employee emp) throws EmployeeIssueException {
		
		emp.setName("Mr. "+emp.getName());
		edao=new EmployeeDAOImpl();
		int eid=edao.addEmployee(emp);
		return eid;
	}
	Employee emp=new Employee();
	public Employee retrieveByEmployeeId(int eid) throws EmployeeIssueException, SQLException {
		
		edao=new EmployeeDAOImpl();
		 emp=edao.retrieveByEmployeeId(eid);
		return emp;
	}

	@Override
	public ArrayList<Employee> retrieveAllEmployeeinfo() throws EmployeeIssueException {
		edao=new EmployeeDAOImpl();
		return edao.retrieveAllEmployeeinfo();
	}

	
	public int deleteByEmployeeId(int eid) throws EmployeeIssueException {
		
		edao=new EmployeeDAOImpl();
		 eid=edao.deleteByEmployeeId(eid);
		return eid;
	}

	@Override
	public String updateEmployeeId(int id, String name)
			throws EmployeeIssueException, SQLException {
		edao=new EmployeeDAOImpl();
		return edao.updateEmployeeId(id,name);
	}
	
	


}

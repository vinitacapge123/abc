package com.cg.ems.ui;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeIssueException;
import com.cg.ems.service.EmployeeServiceImpl;
import com.cg.ems.service.IEmployeeService;
public class Client {
	static Scanner scanner = new Scanner(System.in);
	static Connection con = null;
	static IEmployeeService eserv = null;
	static Employee emp=null;
public static void main(String[] args) throws EmployeeIssueException, SQLException {
		System.out.println("===EmployeemanagementSystem===");
		System.out.println("1. Add employee Info");
		System.out.println("2. Delete employee Info");
		System.out.println("3. Update employee Info");
		System.out.println("4. Retrieve employee by id");
		System.out.println("5. Retrieve All employee Info");
		System.out.println("6. exit");
		System.out.println();
		System.out.println("please enter option : ");
		System.out.println();
		int option = scanner.nextInt();
		switch (option) {
		case 1:
						emp=new Employee();
						System.out.println("enter name ");
						String name = scanner.next();
						eserv=new EmployeeServiceImpl();
						boolean bol=eserv.validateName(name);
				if(bol=true){
					emp.setName(name);
						}
				else
						{
							System.out.println("Name should contain only alphabets and First alphabet should be capital");
						}
				
						emp=new Employee();
						System.out.println("enter email ");
						String email = scanner.next();
						eserv=new EmployeeServiceImpl();
						boolean b=eserv.validateEmail(email);
								if(b=true){
									emp.setMail(email);
								}
								else
								{
									System.out.println("Email is wrong. It should be in this format (abc@capgemini.com)");
								}
				
						System.out.println("enter sal");
						int sal = scanner.nextInt();
						emp.setSal(sal);
						System.out.println("enter mobile ");
						String mob = scanner.next();
						eserv=new EmployeeServiceImpl();
						boolean b1=eserv.validateEmail(mob);
						if(b1=true){
							emp.setMobile(mob);
							
						}
						else
						{
							System.out.println("Email is wrong. It should be in this format (abc@capgemini.com)");
						}
						int empid = addEmployee(emp);
						System.out.println("data is added!!! ur emp id is : " + empid);
								
				break;
						
						
		case 2:
						 emp = new Employee();
						System.out.println("eneter the id u wanna delete");
						int sId = scanner.nextInt();
						deleteEmployee(sId);
		
				break;
		case 3 :            emp = new Employee();
						System.out.println("eneter the id where you want to update");
						int Id = scanner.nextInt();
						System.out.println("enter your name to be updated");
						String name1=scanner.next();
						//emp11.setEmpId(Id);
						//emp11.setName(name);
						updateEmployeeId(Id,name1);
						break;
						
						
		case 4:		emp = new Employee();
					System.out.println("eneter the id u wanna search...");
					int searchId = scanner.nextInt();
					emp=retrieveByEmployeeId(searchId);
					System.out.println(emp);
					break;
							
		case 5:			try {
							ArrayList<Employee> empList=retrieveAll();
								//empList.stream().forEach(System.out::println);
							for(Employee e:empList)
							{
									System.out.println(e);
							}
								
							} 
							catch (EmployeeIssueException e) {
								
								System.err.println(e.getMessage());
							}
							break;
							
		case 6:			System.exit(0);
						
		default:
			
						System.out.println("please enter a valid option between 1-6");
									}
		
}

	private static boolean  validateName(String name) {
	// TODO Auto-generated method stub
		eserv=new EmployeeServiceImpl();
		eserv.validateName(name);
		return true;
	
}
	private static boolean validateEmail(String email) {
		eserv=new EmployeeServiceImpl();
		eserv.validateEmail(email);
		return true;
	}
	private static boolean validateNumber(String mob) {
		eserv=new EmployeeServiceImpl();
		eserv.validateNumber(mob);
		return true;
	}
	private static String updateEmployeeId(int id, String name) throws EmployeeIssueException, SQLException {
		
				eserv=new EmployeeServiceImpl();
				return eserv.updateEmployeeId(id,name);
		
	}
	static Employee e=new Employee();
	
	private static Employee retrieveByEmployeeId(int searchId) throws EmployeeIssueException, SQLException{
		eserv=new EmployeeServiceImpl();
		e=eserv.retrieveByEmployeeId(searchId);
		return e;
	}

	public static int deleteEmployee(int sId)throws EmployeeIssueException{
		eserv=new EmployeeServiceImpl();
		int ret=eserv.deleteByEmployeeId(sId);
		return ret;
	}
	private static ArrayList<Employee> retrieveAll() throws EmployeeIssueException {
		eserv=new EmployeeServiceImpl();
		return eserv.retrieveAllEmployeeinfo();
	}

	static int addEmployee(com.cg.ems.bean.Employee employee)throws EmployeeIssueException {

		eserv = new EmployeeServiceImpl();

		return eserv.addEmployee(employee);

	}
}
		
	



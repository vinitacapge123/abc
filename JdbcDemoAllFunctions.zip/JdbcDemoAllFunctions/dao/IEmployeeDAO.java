package com.cg.ems.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.ems.bean.Employee;
import com.cg.ems.exception.EmployeeIssueException;

public interface IEmployeeDAO {
	public int addEmployee(Employee emp) throws EmployeeIssueException;
	public int deleteByEmployeeId(int eid) throws EmployeeIssueException;
	public Employee retrieveByEmployeeId(int eid) throws EmployeeIssueException, SQLException;
	public ArrayList<Employee> retrieveAllEmployeeinfo() throws EmployeeIssueException;
	public String updateEmployeeId(int id, String name)throws EmployeeIssueException, SQLException;
	
}

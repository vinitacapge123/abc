package com.cg.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.bean.Employee;
import com.cg.ems.dbutil.DBConnectivity;
import com.cg.ems.dbutil.IQueryMapper;
import com.cg.ems.exception.EmployeeIssueException;

public class EmployeeDAOImpl implements IEmployeeDAO {
	Logger log = null;

	public EmployeeDAOImpl() {
		PropertyConfigurator.configure("src/resources/log4j.properties");
		log = Logger.getRootLogger();
		log.setLevel(Level.ALL);
		
	}

	Connection conn = null;

	@Override
	public int addEmployee(Employee emp) throws EmployeeIssueException {
		// db logic
		int retId = 0;
		try {
			log.info("program for insertion started");
			conn = DBConnectivity.getConnected();
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.INSERT_EMPLOYEE_INFO);
			pst.setString(1, emp.getName());
			log.info("name is set :: " + emp.getName());
			pst.setString(2, emp.getMobile());
			pst.setInt(3, emp.getSal());
			pst.setString(4, emp.getMail());
			log.warn("data may not be stored due to DB issue");
			int status = pst.executeUpdate();
			log.info("data is getting stored");
			if (status >= 1) {
				
				pst = conn.prepareStatement(IQueryMapper.EMP_SEQ_CURR_ID);
				ResultSet rs = pst.executeQuery();

				if (rs.next()) {
					retId = rs.getInt(1);
					log.info("data is stored with emp id :: "+retId);
					
				}
			}

		} catch (SQLException e) {
			log.error("error : "+e.getMessage());
			// throw it user defined excep
			throw new EmployeeIssueException("DB problem : " + e.getMessage());

		}
		return retId;
	}

	public Employee retrieveByEmployeeId(int eid) throws SQLException {
		// TODO Auto-generated method stub
		conn=DBConnectivity.getConnected();
		log.info("program for retrive by id ");
		PreparedStatement st=conn.prepareStatement(IQueryMapper.RETRIEVE_EMP_BY_ID);
		st.setInt(1, eid);
		log.info("id is  "+eid);
		ResultSet rs=st.executeQuery();
		log.warn("data may not be fetch from database ");
		Employee re=new Employee();
		if(rs.next()){
			/*System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getString(3));
			System.out.println(rs.getInt(4));
			System.out.println(rs.getString(5));*/
			re.setEmpId(rs.getInt(1));
			re.setName(rs.getString(2));
			re.setMobile(rs.getString(3));
			re.setSal(rs.getInt(4));
			//re.settdate(rs.getString(5));
			//System.out.println(re);
			log.info("data is retrive successfull  by id");
		}
		return re;
		
	}

	@Override
	public ArrayList<Employee> retrieveAllEmployeeinfo()
			throws EmployeeIssueException {
		ArrayList<Employee> empList = new ArrayList<Employee>();
		try {
			conn = DBConnectivity.getConnected();
			log.info("data base is connected ");
			Statement st = conn.createStatement();
			log.info("prepared statment is redy to execute..");
			ResultSet rs = st.executeQuery(IQueryMapper.RETRIEVE_ALL_EMP);
			log.warn("there is problem with your query or database to retrive allthe data");
			Employee emp = null;
			log.warn("there is error to fetch the data from database");
			while (rs.next()) {
				emp = new Employee();
				emp.setEmpId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setMobile(rs.getString(3));
				emp.setSal(rs.getInt(4));
				emp.setMail(rs.getString(5));
				empList.add(emp);
				log.info(" all data is retrive successfull ");
			}

		} catch (SQLException e) {
			log.error("error : "+e.getMessage());
			throw new EmployeeIssueException("exception occured :: "
					+ e.getMessage());
		}

		return empList;
	}
	
	public int deleteByEmployeeId(int eid) throws EmployeeIssueException {
		// TODO Auto-generated method stub
		try {
			conn = DBConnectivity.getConnected();
			log.info("data base is connected ");
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.DELETE_BY_ID_EMP);
			pst.setInt(1, eid);
			log.info("query is redy to execute..");
			int status = pst.executeUpdate();
			log.warn("there is problem with your query or database to retrive by id");
			log.info("data is deleted from table");
			System.out.println("Delete "+status);
			log.info("data is deleted successfull "+status);
		}
		catch (SQLException e1) {
			log.error("error : "+e1.getMessage());
		System.out.println(e1.getMessage());
		}
		return 0;
		
	}

	@Override
	public String updateEmployeeId(int id, String name) {
		try {
			conn = DBConnectivity.getConnected();
			log.info("data base is connected ");
			PreparedStatement pst = conn.prepareStatement("UPDATE Employee1 SET  emp_name=? WHERE emp_id=?");
			pst.setString(1, name);
			pst.setInt(2,id);
			log.info("query is redy to execute..");
			int status = pst.executeUpdate();
			log.warn("there is problem with your query or database to update the data");
			log.info("data is updated from table");
			System.out.println("update "+status);
			log.info("data is updated successfull "+status);
		}
		catch (SQLException e1) {
			log.error("error : "+e1.getMessage());
		System.out.println("Error :"+e1.getMessage());
		}
		return null;
	}


}


package com.capgemini.tcc.dao;

import com.capgemini.tcc.Exceptions.PatientExceptions;
import com.capgemini.tcc.bean.PatientBean;

public interface IPatientDAO {
	
	public abstract int addPatientDetails(PatientBean beanObj) throws PatientExceptions;
	 public abstract PatientBean getPatientDetails(int patientId) throws PatientExceptions;	 

}

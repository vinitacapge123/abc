package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.Exceptions.PatientExceptions;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.util.DBConnector;
import com.capgemini.tcc.util.IQueryMapper;

public class PatientDAO implements IPatientDAO{

	PatientDAO pDAO=null;
	Connection con=null;
	static Logger log=null;
	
	public PatientDAO() {
		PropertyConfigurator.configure("resources/log4j.properties");
		log=Logger.getRootLogger();
	}
	
	@Override
	public int addPatientDetails(PatientBean beanObj) throws PatientExceptions 
	{
		pDAO.log.info("Adding Patient Being Started ! ");
		int pId=0;
		try {
			
			con=DBConnector.getConnected();
			
			pDAO.log.info("Database connection successfull for inserting details");
			
			PreparedStatement ps=con.prepareStatement(IQueryMapper.ADD_PATIENT);
			ps.setString(1,beanObj.getPatientName());
			ps.setInt(2, beanObj.getAge());
			ps.setString(3, beanObj.getPhoneNo());
			ps.setString(4, beanObj.getDescription());
			ps.executeUpdate();
			
			pDAO.log.info("Inserted records successfully!");
			
			ps=con.prepareStatement(IQueryMapper.PATIENT_ID);
			ResultSet result=ps.executeQuery();
			
			pDAO.log.info("Executed PATIENT ID query");
			
			if(result.next())
			{
				pId=result.getInt(1);
				
				pDAO.log.info("Fetched Patient ID successfully");

			}
			catch (SQLException e)
			{
				pDAO.log.fatal("Exception occured during adding patient Details ....");
					
				throw new PatientExceptions("Error occured in adding patients"); 
			}
		return pId;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientExceptions {
		
		PatientBean pb=null;
		try {
			
			
			con=DBConnector.getConnected();
			
			pDAO.log.info("Database connection successfull for Fetching details ...");
			PreparedStatement ps=con.prepareStatement(IQueryMapper.PATIENT_DETAILS);
			ps.setInt(1,patientId);
			ResultSet rs=ps.executeQuery();
			pDAO.log.info("Query Executed for fetching details..");
			if(rs.next())
			{
				 pb=new PatientBean();
				 pb.setPatientName(rs.getString(2));
				 pb.setAge(rs.getInt(3));
				 pb.setPhoneNo(rs.getString(4));
				 pb.setDescription(rs.getString(5));
				 Date d=new Date();
				 d=rs.getDate(6);
				 pb.setConsultationDate(d);
			}
			
		} catch (SQLException e) {
			
			pDAO.log.fatal("Exception occured during fetching detail Details ....");
			
			throw new PatientExceptions("Error occured in fetching details..."); 
		}
		
		return pb;
	}
	 
}

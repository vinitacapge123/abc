/*
 * Author      : Rohan soudey
 * Created On  : 27/07/2018
 * Name        : Client.java
 * Description : user Interface which display the menu and accept the inputs from user 
 */

package com.capgemini.tcc.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.omg.PortableServer.POA;

import com.capgemini.tcc.Exceptions.PatientExceptions;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.service.*;

public class Client {

	static PatientBean beanObj=null; 
	static IPatientService pServ=null;
	static int  option;
	public static void main(String[] args) 
	{
		beanObj=new PatientBean();
		pServ=new PatientService();
		Scanner scan=new Scanner(System.in);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		do
		{
			System.out.println("1. Add Patient information");
			System.out.println("2. Search Patient Id");
			System.out.println("3. Exit");
			
			
			System.out.println("Enter Option : ");
			option=scan.nextInt();
			switch(option)
			{
				case 1:
					try{
						System.out.print("Enter the name of the Patient: ");
						
						String patientName="";
							try 
							{
								patientName = br.readLine();
							} 
							catch (IOException e) 
							{
								throw new PatientExceptions("Error Occured during entering name");
							}
						if(pServ.validateName(patientName)==1) //validation
						{
							System.out.println("\nPatient name is not valid !! \n");
							break;
						}
						else
						{
							beanObj.setPatientName(patientName);
						}
						
						System.out.print("Enter Patient Age: ");
						int age=0;
						
						try{
						age=scan.nextInt();
						}
						catch(InputMismatchException e)
						{
							throw new PatientExceptions("\nTYPED WRONGLY\n");
						}
						
						if(!pServ.validateAge(age)) //validation
						{
							System.out.println("\nPatient Age is invalid\n");
							break;
						}
						else
						{
							beanObj.setAge(age);
						}
						System.out.print("Enter Patient Phone number: ");
						String phoneNo=scan.next();
						
						if(pServ.validatephone(phoneNo)==1)//validation
						{
							System.out.println("\nPhone number is invalid (enter 10 digit phone number)\n");
							break;
						}
						else
						{
							beanObj.setPhoneNo(phoneNo);
						}
						
						System.out.print("Enter Description:");
						String description="";
						try 
						{
							description= br.readLine();
						} 
						catch (IOException e) 
						{
							throw new PatientExceptions("\nError Occured during entering Description\n");
						}
						beanObj.setDescription(description);
					
						System.out.println("\nPatient Information stored successfully for Patient ID : "+addPatientDetails(beanObj)+"\n");
					}
					
					catch (PatientExceptions p) {
						
						System.out.println("\n"+p.getMessage()+"\n");
					}
					break;
					
				case 2:
				try 
				{
					System.out.print("Enter Patient ID : ");
					int input=scan.nextInt();
					if(getPatientDetails(input)!=null)
					{
						System.out.println("\n"+getPatientDetails(input)+"\n");
					}
					else
					{
						System.out.println("\nThere is no patient with this ID\n");
					}
					
				}
				catch (PatientExceptions e) {
					System.out.println("\n"+e.getMessage()+"\n");
				}
					break;
				case 3:
					System.out.println("Thank you !!");
					System.exit(0);
					break;
				default:
					System.out.println("\nPlease choose valid option ! ! \n");
			}
			
		}
		while(option!=3);
	}
	private static int addPatientDetails(PatientBean beanObj2) throws PatientExceptions {
		
		pServ=new PatientService();
		
		return pServ.addPatientDetails(beanObj2);
		
	}
	public static PatientBean getPatientDetails(int patientId) throws PatientExceptions
	{
		pServ=new PatientService();
		
		return pServ.getPatientDetails(patientId);
		
	}

}

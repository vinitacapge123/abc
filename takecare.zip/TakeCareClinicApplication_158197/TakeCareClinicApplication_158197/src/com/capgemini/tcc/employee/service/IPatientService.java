/*
 * Author      : Rohan Soudey
 * Created On  : 27/07/2018
 * Name        : IPatientService.java
 * Description : Interface containing methods and implemented by PatientService.java 
 */


package com.capgemini.tcc.service;

import com.capgemini.tcc.Exceptions.PatientExceptions;
import com.capgemini.tcc.bean.PatientBean;



public interface IPatientService {
	
	 public abstract int addPatientDetails(PatientBean beanObj) throws PatientExceptions;
	 public abstract PatientBean getPatientDetails(int patientId) throws PatientExceptions;	 
	 
	 public abstract int validateName(String name);
	 public abstract boolean validateAge(int age);
	 public abstract int validatephone(String phoneNo);
	 
	
}

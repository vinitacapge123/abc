package com.capgemini.tcc.Exceptions;

public class PatientExceptions extends Exception{
	
	public PatientExceptions(String message) {
		super(message);
	}
	

}

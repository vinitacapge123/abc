




package com.capgemini.tcc.util;

public interface IQueryMapper {
	
	public static final String ADD_PATIENT="insert into patient values(patient_id_seq.NEXTVAL,?,?,?,?,sysdate)";
	public static final String PATIENT_ID="select patient_id_seq.CURRVAL from dual";
	public static final String PATIENT_DETAILS="select * from patient where patient_id=?";
	

}

package com.capgemini.tcc.test;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;

public class PatientTest {
	
	@Test
	void testinsert()
	{
		 PatientBean pb=new PatientBean();
		 pb.setPatientName("ROHAN");
		 pb.setAge(12);
		 pb.setPhoneNo("9870727166");
		pb.setDescription("Description");
		
		
		Assert.assertEquals("FAILED",1,1);
		
	}

}

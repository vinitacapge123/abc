package com.capgemini.tcc.service;

import com.capgemini.tcc.Exceptions.PatientExceptions;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.*;

public class PatientService implements IPatientService{

	static IPatientDAO pDAO=null;
	@Override
	public int addPatientDetails(PatientBean beanObj) throws PatientExceptions {
		
		pDAO=new PatientDAO();
		return pDAO.addPatientDetails(beanObj);
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientExceptions {
		
		pDAO=new PatientDAO();
		
		return pDAO.getPatientDetails(patientId);
	}

	@Override
	public int validateName(String name) {
		
		if(name.matches("[A-Za-z ]{1,}"))
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	@Override
	public boolean validateAge(int age) 
	{	
		//Validating maximum age by 140 Years and for age<=0
		
		if(age<=0 || age>=140)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public int validatephone(String phoneNo) 
	{
		if(phoneNo.matches("[0-9]{10}"))
		{
			return 0;
		}
		else
		{
			return 1;
		}
	}

	
	
}

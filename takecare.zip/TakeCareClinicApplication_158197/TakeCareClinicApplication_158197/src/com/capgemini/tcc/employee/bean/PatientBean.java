/*
 * Author      : Rohan soudey
 * Created On  : 27/07/2018
 * Name        : PatientBean.java
 * Description : Bean class for patient with all required details 
 */



package com.capgemini.tcc.bean;

import java.util.Date;

public class PatientBean {

	private int patientId;
	private String patientName;
	private int age;
	private String phoneNo;
	private String description;
	private Date consultationDate;
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getConsultationDate() {
		return consultationDate;
	}
	public void setConsultationDate(Date consultationDate) {
		this.consultationDate = consultationDate;
	}
	@Override
	public String toString() {
		return "Name of the Patient: " + patientName +"\nAge:   " + age + "\nPhone Number: " + phoneNo
				+ "\nDescription:  " + description + "\nConsultation Date:"
				+ consultationDate;
	}
	
	
}

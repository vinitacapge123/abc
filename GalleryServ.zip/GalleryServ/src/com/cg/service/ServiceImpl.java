package com.cg.service;

public class ServiceImpl implements IServiceInterface {
  
	@Override
	public boolean validateName(String name) {
		if(name.equals("user"))
			return true;
		else
		return false;
	}

	@Override
	public boolean validatePswd(String pswd) {
		if(pswd.equals("user"))
			return true;
		else
		return false;
	}
}

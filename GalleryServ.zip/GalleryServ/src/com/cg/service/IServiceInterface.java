package com.cg.service;

public interface IServiceInterface {
	public boolean validateName(String name);
	public boolean validatePswd(String pswd);
}

package com.cg.model;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CustomerServ
 */
@WebServlet("/customerServ")
public class CustomerServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Customer cust=new Customer();
		cust.setUserName(req.getParameter("userName"));
		cust.setEmail(req.getParameter("eMail"));
		cust.setMobileNumber(req.getParameter("mobileNumber"));
		String target="registerServlet";
				RequestDispatcher rd=req.getRequestDispatcher(target);
				req.setAttribute("customerObject",cust);
				rd.forward(req, resp);
		
	}

}

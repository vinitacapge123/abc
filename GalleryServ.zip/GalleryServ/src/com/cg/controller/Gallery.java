package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Gallery
 */
@WebServlet("/gallery")
public class Gallery extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
          PrintWriter out=null;
 

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		out=response.getWriter();
		out.println("<html>");
		out.println("<body>");
		//out.println("no of times visited: "+(++count));
		out.println("<form action='show' method='get'>");
		out.println("<a href='show?fid=101&fname=KFC&fprice=200'><image src='images/image1.jpg' height='70px' width='70px'>KFC</image></a>");
		out.println("<a href='show?fid=102&fname=RedVelvetCake&fprice=500'><image src='images/image2.jpg' height='70px' width='70px'>CAKE</image></a>");
		out.println("<a href='show?fid=103&fname=ChickenWings&fprice=300'><image src='images/image3.jpg' height='70px' width='70px'>CHICKEN</image></a>");
		out.println("<a href='show?fid=104&fname=MCDonalds&fprice=250'><image src='images/image4.jpg' height='70px' width='70px'>MCDONALDS</image></a>");
		out.println("</form>");
		out.println("</body>");
		out.println("</html>");
	}
}

package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.service.*;


/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	 PrintWriter out=null;
		IServiceInterface ic=null;
 public Login() {
     super();
 }
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
 {
 	out=response.getWriter();
		String name=request.getParameter("name");
		String pswd=request.getParameter("pswd");
		
		ic=new ServiceImpl();
		
		if(ic.validateName(name) && ic.validatePswd(pswd))
		{
			
			RequestDispatcher rs=request.getRequestDispatcher("gallery");
			rs.forward(request, response);
		}
		else
			out.println("login not successful!");
		
	}

}
